package com.TaranjeetSingh;

public interface Shape {
    double getPerimeter();

    int hashCode();
    boolean equals(Object obj);
}
